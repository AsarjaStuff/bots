require("dotenv").config();

const { TOKEN } = process.env;
const { Client, Collection, Partials, GatewayIntentBits } = require("discord.js");
const fs = require("fs");

const client = new Client({
    fetchAllMembers: true,
    intents: [32767, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMessages, GatewayIntentBits.GuildMembers ],
    partials: [
        Partials.Channel,
        Partials.Message,
    ],
  });
client.commands = new Collection();
client.commandArray = [];

const functionFolders = fs.readdirSync(`./src/functions`);
for (const folder of functionFolders) {
  const functionFiles = fs
    .readdirSync(`./src/functions/${folder}`)
    .filter((file) => file.endsWith(`.js`));
  for (const file of functionFiles) {
    require(`./functions/${folder}/${file}`)(client);
  }
}

//IF BOT DOESNT WORK MAKE SURE TO CHECK "HANDLE COMMANDS" AND CHANGE CLIENT ID TO THE RIGHT ONE
client.handleEvents();
client.handleCommands();
client.login(TOKEN);