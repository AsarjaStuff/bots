module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        if (interaction.isChatInputCommand()) {
            const { commands } = client;
            const { commandName } = interaction;
            const command = commands.get(commandName);
            if (!command) return;

            try {
                await command.execute(interaction, client);
            } catch (error) {
                console.error(error);
                await interaction.reply({
                    content: `Something went wrong while using this command:\n\`\`\`diff\n-ERROR CODE: ${error.code}\nDESCRIPTION: ${error.message}\n\`\`\``,
                    ephemeral: true,
                    embeds: [],
                    components: []
                }).catch(async err => {
                    await interaction.editReply({
                        content: `Something went wrong while using this command:\n\`\`\`diff\n-ERROR CODE: ${error.code}\nDESCRIPTION: ${error.message}\n\`\`\``,
                        ephemeral: true,
                        embeds: [],
                        components: []
                    }).catch(err => {
                        return interaction.channel.send({
                            content: `Something went wrong while using this command:\n\`\`\`diff\n-ERROR CODE: ${error.code}\nDESCRIPTION: ${error.message}\n\`\`\``,
                            ephemeral: true,
                            embeds: [],
                            components: []
                        }).catch(err);
                    });
                });
            }
        }
    }
}