module.exports = {
    name: 'ready',
    once: 'true',
    async execute(client) {
        console.log(`Logged in discord as ${client.user.tag} [${client.user.id}]`);
    }
};