require('dotenv').config();

const HOST1 = process.env.HOST1;
const USER1 = process.env.USER1;
const PASSWORD1 = process.env.PASSWORD1;
const DATABASE1 = process.env.DATABASE1;

const mysql = require("mysql");
const connection = mysql.createConnection({
    host: HOST1,
    user: USER1,
    password: PASSWORD1,
    database: DATABASE1
})

module.exports = {
    countRows,
    getQuery,
    executeUpdate,
    connection: connection
}

async function countRows(tablename, restStatement) {
    const sql = "SELECT COUNT(*) AS rowCount FROM `" + tablename + "` " + restStatement;

    const res = await new Promise((resolve, reject) => {
        connection.query(sql, (err, result) => {
            if(err){
                reject(err);
                return;
            } else {
                resolve(result);
            }
        })
    })
    return(parseInt(res[0].rowCount));
}
async function getQuery(statement) {
    const sql = statement;

    const res = await new Promise((resolve, reject) => {
        connection.query(sql, (err, result) => {
            if(err){
                reject(err);
                return;
            } else {
                resolve(result);
            }
        })
    })
    return(res);
}
function executeUpdate(statement) {
    connection.query(statement, (err, result) => {
    if(err) console.log(err);
    });
}